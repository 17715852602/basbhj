import os
from llm_api import LLMClient
from prompt_template import TESTCASE_GENERATE_PROMPT, TESTCASE_OPTIMIZE_PROMPT
from config import OUTPUT_FOLDER

os.makedirs(OUTPUT_FOLDER, exist_ok=True)
llm = LLMClient()

def save_result(filename, data):
    path = os.path.join(OUTPUT_FOLDER, filename)
    with open(path, "w", encoding="utf-8") as f:
        f.write(data)

def generate_standard_testcase(business_content: str) -> str:
    """根据业务需求自动生成完整测试用例"""
    prompt = TESTCASE_GENERATE_PROMPT.replace("{{content}}", business_content)
    res = llm.generate(prompt)
    save_result("原始生成测试用例.md", res)
    return res

def optimize_testcase(testcase_text: str) -> str:
    """对生成用例进行校验、结构化、优化整理"""
    prompt = TESTCASE_OPTIMIZE_PROMPT.replace("{{content}}", testcase_text)
    res = llm.generate(prompt)
    save_result("优化后结构化测试用例.md", res)
    return res

def full_auto_flow(business_content: str) -> str:
    """全自动流程：需求输入 → 生成用例 → 校验优化 → 结构化输出"""
    raw = generate_standard_testcase(business_content)
    final = optimize_testcase(raw)
    return final