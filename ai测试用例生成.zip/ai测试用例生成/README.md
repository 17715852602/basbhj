AI 驱动的自动化测试用例生成系统


```bash
pip install -r requirements.txt