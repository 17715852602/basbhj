
LLM_CONFIG = {
    "api_key": "",
    "base_url": "https://api.openai.com/v1",
    "model": "gpt-3.5-turbo",
    "temperature": 0.1,
    "timeout": 60
}

OUTPUT_FOLDER = "outputs"