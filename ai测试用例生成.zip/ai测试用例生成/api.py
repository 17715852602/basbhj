import requests
from config import LLM_CONFIG

class LLMClient:
    """统一大模型接口封装，支持通用对话调用"""
    def __init__(self):
        self.headers = {
            "Authorization": f"Bearer {LLM_CONFIG['api_key']}",
            "Content-Type": "application/json"
        }
        self.url = f"{LLM_CONFIG['base_url']}/chat/completions"

    def generate(self, prompt: str) -> str:
        payload = {
            "model": LLM_CONFIG["model"],
            "messages": [{"role": "user", "content": prompt}],
            "temperature": LLM_CONFIG["temperature"]
        }
        try:
            res = requests.post(self.url, json=payload, headers=self.headers, timeout=LLM_CONFIG["timeout"])
            return res.json()["choices"][0]["message"]["content"]
        except Exception as e:
            return f"模型调用失败：{str(e)}"