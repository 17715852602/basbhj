from testcase_core import full_auto_flow

def main():
    print("="*60)
    print("     AI 驱动的自动化测试用例生成系统")
    print("     需求文本 → 全自动生成功能/边界/异常测试用例")
    print("="*60)

    while True:
        print("\n1. 输入业务需求，全自动生成结构化测试用例")
        print("0. 退出程序")
        choice = input("请选择功能：")

        if choice == "1":
            content = input("\n请输入业务需求/接口功能描述：\n")
            print("\n🚀 AI 正在生成并优化测试用例...")
            result = full_auto_flow(content)
            print("\n✅ 最终结构化测试用例：\n")
            print(result)

        elif choice == "0":
            print("程序退出")
            break

if __name__ == "__main__":
    main()