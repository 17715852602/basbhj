# 大模型全局配置
MODEL_CONFIG = {
    "provider": "openai",
    "api_key": "",
    "base_url": "https://api.openai.com/v1",
    "model_name": "gpt-3.5-turbo",
    "timeout": 60
}

# 工具全局配置
OUTPUT_DIR = "outputs"
AUTO_SAVE = True