import os
from llm_api import LLMAPI
from prompts import *
from config import OUTPUT_DIR

os.makedirs(OUTPUT_DIR, exist_ok=True)
llm = LLMAPI()

def save_file(filename: str, content: str):
    save_path = os.path.join(OUTPUT_DIR, filename)
    with open(save_path, "w", encoding="utf-8") as f:
        f.write(content)

def generate_code(requirement: str) -> str:
    prompt = PROMPT_CODE_GENERATE.replace("{{content}}", requirement)
    result = llm.chat(prompt)
    save_file("代码生成结果.txt", result)
    return result

def generate_test_case(api_info: str) -> str:
    prompt = PROMPT_TEST_CASE.replace("{{content}}", api_info)
    result = llm.chat(prompt)
    save_file("接口测试用例.md", result)
    return result

def add_code_comment(code: str) -> str:
    prompt = PROMPT_COMMENT.replace("{{content}}", code)
    result = llm.chat(prompt)
    save_file("补全注释代码.py", result)
    return result

def check_code_standard(code: str) -> str:
    prompt = PROMPT_CODE_CHECK.replace("{{content}}", code)
    result = llm.chat(prompt)
    save_file("代码规范检测报告.txt", result)
    return result

def generate_param_rules(param_info: str) -> str:
    prompt = PROMPT_PARAM_CHECK.replace("{{content}}", param_info)
    result = llm.chat(prompt)
    save_file("接口参数校验规则.txt", result)
    return result