import requests
from config import MODEL_CONFIG

class LLMAPI:
    """大模型API统一封装，兼容多模型扩展"""
    def __init__(self):
        self.api_key = MODEL_CONFIG["api_key"]
        self.base_url = MODEL_CONFIG["base_url"]
        self.model = MODEL_CONFIG["model_name"]
        self.headers = {"Authorization": f"Bearer {self.api_key}"}

    def chat(self, prompt: str) -> str:
        """统一对话调用入口"""
        try:
            data = {
                "model": self.model,
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 0.2
            }
            res = requests.post(
                f"{self.base_url}/chat/completions",
                headers=self.headers,
                json=data,
                timeout=MODEL_CONFIG["timeout"]
            )
            return res.json()["choices"][0]["message"]["content"]
        except Exception as e:
            return f"LLM API调用异常: {str(e)}"