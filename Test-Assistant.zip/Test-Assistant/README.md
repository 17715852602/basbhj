基于大模型的智能代码辅助与测试工具
安装依赖
```bash
pip install -r requirements.txt