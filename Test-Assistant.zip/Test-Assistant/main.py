from core_functions import *

def main():
    print("=" * 55)
    print("   基于大模型的智能代码辅助与测试工具")
    print("=" * 55)
    print("功能：代码生成 | 测试用例 | 注释补全 | 规范检查 | 参数校验")
    print("=" * 55)

    while True:
        print("\n【功能菜单】")
        print("1. 智能代码自动生成")
        print("2. 接口测试用例批量生成")
        print("3. 代码注释一键补全")
        print("4. 代码规范合规检查")
        print("5. 接口参数校验规则生成")
        print("0. 退出程序")

        select = input("\n请输入功能序号：").strip()

        if select == "1":
            text = input("请输入代码开发需求：")
            print("\n🔹生成结果：\n", generate_code(text))
        elif select == "2":
            text = input("请输入接口详细信息：")
            print("\n🔹测试用例：\n", generate_test_case(text))
        elif select == "3":
            text = input("请粘贴需要补注释的代码：")
            print("\n🔹注释补全完成：\n", add_code_comment(text))
        elif select == "4":
            text = input("请粘贴待检测代码：")
            print("\n🔹规范检测报告：\n", check_code_standard(text))
        elif select == "5":
            text = input("请输入接口参数信息：")
            print("\n🔹参数校验规则：\n", generate_param_rules(text))
        elif select == "0":
            print("\n✅ 程序已退出")
            break
        else:
            print("\n❌ 输入序号错误，请重新选择")

if __name__ == "__main__":
    main()